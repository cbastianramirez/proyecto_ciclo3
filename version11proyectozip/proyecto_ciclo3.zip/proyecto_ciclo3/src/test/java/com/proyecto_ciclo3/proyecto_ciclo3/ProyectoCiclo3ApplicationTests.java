package com.proyecto_ciclo3.proyecto_ciclo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCiclo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
